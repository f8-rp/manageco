import * as React from "react";
import {
  Text,
  View,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  ImageBackground
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { FontAwesome } from "@expo/vector-icons";
import firebase from 'firebase'

const image = {uri: "welcomebkg.png"};

export default class Welcome extends React.Component {

  componentDidMount(){
      firebase.auth().onAuthStateChanged((user) => {
      if (user) {
        var uid = user.uid;
        this.props.navigation.navigate("Home")
        // ...
      } else {
        this.props.navigation.navigate("Welcome")
      }
  });
  }
  render() {
    return (
      <View style={{ flex: 1, backgroundColor:"#BF09BD"}}>
      <ImageBackground source={require('../assets/welcome.png')} style={{width:'100%', height:'100%'}}>
      <ScrollView>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginTop: "15%",
              marginLeft:6,
              justifyContent:'center'
            }}
          >
          </View>


          <TouchableOpacity
            style={{
              borderWidth: 3,
              borderRadius: 10,
              height: 40,
              justifyContent: "center",
              alignItems: "center",
              width: "60%",
              alignSelf: "center",
              marginTop: 550,
              backgroundColor: "#F9F4E5",
            }}
            onPress={()=>{
              this.props.navigation.navigate("Login")
            }}
          >
            <Text style={{ fontWeight: "bold", color: "black", fontSize: 20 }}>
              Log In
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              borderWidth: 3,
              borderRadius: 10,
              height: 40,
              justifyContent: "center",
              alignItems: "center",
              width: "60%",
              alignSelf: "center",
              marginTop: 10,
              backgroundColor: "#F9F4E5",
              marginBottom:20
            }}
            onPress={()=>{
              this.props.navigation.navigate("SignUp")
            }}
          >
            <Text style={{ fontWeight: "bold", color: "black", fontSize: 20 }}>
              Sign Up
            </Text>
          </TouchableOpacity>
        </ScrollView>
        </ImageBackground>
      </View>
    );
  }
}
